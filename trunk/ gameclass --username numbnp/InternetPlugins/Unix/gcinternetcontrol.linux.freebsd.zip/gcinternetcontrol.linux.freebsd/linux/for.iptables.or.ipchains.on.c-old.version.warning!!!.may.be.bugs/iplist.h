// *****************************************************
// *              (C) NodaSoft 2000-2006               *
// *****************************************************

// here is placed command files
#define MODULE_PATH "/etc/gc"

// listen udp port (always 3775)
#define UDP_PORT 3775

// CG server port (always 3773)
#define CG_UDP_PORT 3773

// UDP Packet buffer len (recommended 4096 (4096 >= MAX_IPLIST*36 bytes) )
#define IN_BUFFER_LEN 4096

// maximum len of command for unix (recommended 512)
#define COMMAND_BUFFER_LEN 512

// maximum quantity of ip-addresses (client computers)
#define MAX_IPLIST 100

// functions for manipulate with list of ip
void IpListInitialize(void);
int  IpListIn(char *ip);
void IpListAdd(char *ip);
void IpListRemove(char *ip);

typedef struct ipliststruct
{
  char ip[16];		// ip-address
  int  blocked;		// 1 - blocked, 0 - not blocked (traffic)
  long traf_speed;	// maximum speed (bytes/sec), if 0 - then no limit
  long traf_limit;	// maximum traffic (bytes), if 0 - then no limit
  long traf_in;		// in traffic (bytes)
  long traf_out;	// out traffic (bytes)
} ipliststruct;

