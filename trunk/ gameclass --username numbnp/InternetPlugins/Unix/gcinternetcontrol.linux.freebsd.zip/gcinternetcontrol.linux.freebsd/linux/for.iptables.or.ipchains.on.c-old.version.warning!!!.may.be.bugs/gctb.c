// *****************************************************
// *              (C) NodaSoft 2000-2006               *
// *****************************************************
// *   Traffic Billing Module v 1.0 for GameClass      *
// *   HomePage http://www.nodasoft.com/products/gc/   *
// *   Create by NodaSoft                              *
// *****************************************************

#include <netinet/in.h>                     
#include <sys/socket.h>
#include <stdio.h>
#include "iplist.h"
#include <signal.h>
#include <syslog.h>
#include <time.h>
#include <sys/resource.h>
#include <unistd.h>

ipliststruct iplist[MAX_IPLIST]; 	// iplist array
int	iplistmax;						// quantity ip in iplist (count elements in iplist)

char buffer[IN_BUFFER_LEN];			// buffer for udp-packet
char command[COMMAND_BUFFER_LEN];	// string with command for unix
char ip[16];						// ip address
char tarif_name[300];				// tarif_name
struct sockaddr_in local, from;

void GetTrafficInformationFromFirewall();
int GenerateAnswerForGameClass();

// entry point
int main(void)
{
  // ------ socket's variables --------
  int fromlen;
  int listen_socket, msgsock;
  int k;k=0;
  int  fd;
  struct  rlimit  flim;
  
  // daemon initialisation part
  if( getppid() != 1 )
  {
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    if( fork()!=0 )
	{
	  exit(0);
    }
    setsid();
  }

  getrlimit(RLIMIT_NOFILE, &flim);
  for (fd = 0; fd < flim.rlim_max; fd++)close(fd);
  chdir("/");

  openlog("TbmGCd", LOG_PID | LOG_CONS, LOG_DAEMON);
  syslog(LOG_INFO, "daemon started");
  closelog();
  // end of daemon initialisation part
  
  // DELETING ALL RULES FROM tables
  strcpy(command,MODULE_PATH);
  strcat(command,"/reset_reject");
  system(command);

  printf("\n(C) NodaSoft 2000-2006\n");  
  printf("Traffic Billing Module for GameClass is started ...\n");

  IpListInitialize();

  // initializing UDP socket
  local.sin_family = AF_INET;
  local.sin_addr.s_addr = htonl(INADDR_ANY);
  local.sin_port = htons(UDP_PORT);

  // can be socket open?
  listen_socket = socket(AF_INET, SOCK_DGRAM,0);
  if (listen_socket == -1) 
  {
    printf("Error: socket already opened!\n");
    openlog("TbmGCd", LOG_PID | LOG_CONS, LOG_DAEMON);
    syslog(LOG_INFO, "Error: socket already opened!");
    closelog();
    exit(1);
  }

  if (bind(listen_socket,(struct sockaddr*)&local,sizeof(local) ) == -1) 
  {
    printf("Error: Listen socket!\n");
    openlog("TbmGCd", LOG_PID | LOG_CONS, LOG_DAEMON);
    syslog(LOG_INFO, "Error: Listen socket!");
    closelog();
    exit(1);
  }
  
  // socket open successfully  
  // go working

  while(1) 
  {
    fromlen = sizeof(from);
    msgsock = listen_socket;
    memset(buffer,0,IN_BUFFER_LEN);
	
	// waiting query (UDP-Packet) from GameClass Server
    recvfrom(msgsock,buffer,sizeof(buffer),0,(struct sockaddr *)&from,&fromlen);

	// command from server	
	/*********************************************/
    if (strstr(buffer,"inet_block"))
    {
      strcpy(command,MODULE_PATH);
      strcat(command,"/template_block ");
      strcat(command,strstr(buffer,"=")+1);
      strcpy(ip,strstr(buffer,"=")+1);
      if (IpListIn(ip)) 
	  {
        // here is added new Firewall rule (blocking)
	    system(command);				
	    IpListRemove(ip);
	  }
	}
    /*********************************************/
    if (strstr(buffer,"inet_unblock"))
    {
      strcpy(command,MODULE_PATH);
      strcat(command,"/template_unblock ");
	  
	  strcpy(tarif_name, ""); // clear tarif_name variable
	  if (strstr(buffer,"/")) // if format is "inet_unblock=ip/tarif_name"
	  {
		strcpy(tarif_name, strstr(buffer,"/")+1);	// copy tarif_name to tarif_name variable
		*strstr(buffer,"/")=0;						// change command from "inet_unblock=ip/tarif_name" to "inet_unblock=ip" 
		strcat(command,strstr(buffer,"=")+1);		// add ip to command, sample "/etc/gc/template_unblock 192.168.0.4"
		// add tarif_name to command 
		// uncomment this section, if you want send tarif_name to template_unblock script
		/*
		strcat(command," ");
		strcat(command,tarif_name);  // sample "/etc/gc/template_unblock 192.168.0.4 internet-fast"
		*/
	  }
	  else
	  {
	    strcat(command,strstr(buffer,"=")+1);		// add ip to command, sample "/etc/gc/template_unblock 192.168.0.4"
	  };

      strcpy(ip,strstr(buffer,"=")+1); // copy ip to ip variable
	  
	  // ToDo Exctract second parameter - tarif name
      if (!IpListIn(ip)) 
	  {
        // here is romeved Firewall rule (unblocking)
	    printf("%s \n",command);
	    system(command);
	    IpListAdd(ip);
	  }

    }
    /*********************************************/
    if (strstr(buffer,"inet_set_speed_for_ip"))
    {
		// currently not supported
    }
	/*********************************************/
    if (strstr(buffer,"inet_get_traffic_value"))    
	{
	  printf ("generate traffic\n");
	  GetTrafficInformationFromFirewall();
	  if (GenerateAnswerForGameClass())
	  {
		 // send answer (using UDP Socket)
		 printf ("Send UDP %s\n",buffer);
		 from.sin_port		 = htons(CG_UDP_PORT);
		 sendto(msgsock,buffer,strlen (buffer),0,(struct sockaddr *)&from,fromlen);
	  }
    }  

	/*********************************************/
    // printf("%s\n",buffer);
	/*********************************************/
  }
  close(listen_socket);
  return -1;
}

// return 1, if exist info for >0 ip's, else return 0
int GenerateAnswerForGameClass()
{
	int i;
	int exist_info;
	char temp_buffer[100];

	// clear buffer
	buffer[0]=0;
	// set prefix for GameClass
	strcat(buffer, "v01.inet_get_traffic_value_answer=");

	exist_info = 0;
	for (i=0; i<iplistmax; i++)
	
	if ((iplist[i].traf_in>0) || (iplist[i].traf_out>0))
	{
		exist_info = 1;
		// add ip
		strcat(buffer, iplist[i].ip);
		strcat(buffer, "/");
		// add traf_in
		snprintf(temp_buffer, 100, "%d", iplist[i].traf_in); 
		strcat(buffer, temp_buffer);
		strcat(buffer, "/");		
		// add traf_out
		snprintf(temp_buffer, 100, "%d", iplist[i].traf_out);
		strcat(buffer, temp_buffer);
		strcat(buffer, "/");
		// clear counters
		ip_reset(&iplist[i]);
	}
	// truncate last "/"
	strcpy (temp_buffer, "/");
	if (buffer[strlen(buffer)-1] == temp_buffer[0]) 
		buffer[strlen(buffer)-1] = 0;
	return exist_info;
}

// this function retrieve data from linux firewall, parse this data and put to 
// iplist array
void GetTrafficInformationFromFirewall()
{
	strcpy(command,MODULE_PATH);
	strcat(command,"/get_traf >/tmp/input_file");
	system(command);
	// run command and receive results from linux (from iptables)

	char s[20];
	long x,y;
	int i;
	FILE *in=fopen("/tmp/input_file","r");

   	while (!feof(in))
   	{
   	if ((fscanf(in,"%s %d %d",s,&x,&y))==3)
   	 {
	 	for (i=0; i<iplistmax;i++)
		{
			if (strncmp(iplist[i].ip,s,strlen(iplist[i].ip))==0)
		 	{ 
			  iplist[i].traf_in +=y;
			  iplist[i].traf_out+=x;
			  break;
			}
		};
		
	 };
   	};

	fclose(in);
	in = fopen("/tmp/input_file","w");
	fclose(in);
	// parse results and put it to iplist array
}

