// *****************************************************
// *              (C) NodaSoft 2000-2005               *
// *	      (C) a LOT of bugfixes by GoodOne         *
// *****************************************************
#include "iplist.h"

extern ipliststruct iplist[MAX_IPLIST];
extern int iplistmax;

// already exists checking
int IpListIn(char *ip)
{
  int i;
  for(i=0;i <= iplistmax; i++)
    if (strcmp(iplist[i].ip, ip) == 0)
	  return(1);
  return(0);
}

// add new ip to iplist
void IpListAdd(char *ip)
{
  int i;
  if (IpListIn(ip)) return;

  for(i=0; i<=MAX_IPLIST; i++)
    if(iplist[i].ip[0] == 0)
	{
	  strcpy(iplist[i].ip,ip);
	  iplist[i].traf_in=0;
	  iplist[i].traf_out=0;
	  iplist[i].overall_in=0;
	  iplist[i].overall_out=0;
	  if (i > iplistmax) iplistmax = i;
	  return;
	}
}

// remove ip from iplist
void IpListRemove(char *ip)
{
  int i;
  for(i=0 ; i <= iplistmax; i++)
    if(strcmp(iplist[i].ip,ip) == 0)
	{
	  iplist[i].ip[0] = 0;
	  iplist[i].traf_in  = 0;
	  iplist[i].traf_out = 0;
	  iplist[i].overall_in  = 0;
	  iplist[i].overall_out = 0;
	  return;
	}
}

// initialize iplist
void IpListInitialize(void)
{
  int i;
	
  iplistmax = 0;
	
  for(i=0;i <= MAX_IPLIST;i++)
  {
    iplist[i].ip[0]=0;
    iplist[i].blocked=0;
    iplist[i].traf_speed=0;
    iplist[i].traf_limit=0;
    iplist[i].traf_in=0;
    iplist[i].traf_out=0;
    iplist[i].overall_in=0;
    iplist[i].overall_out=0;
  }
}

void IpListDefrag(void)
{
  int i, j;

  for(i=0;i <= MAX_IPLIST;i++)
  {
    if (strlen(iplist[i].ip) == 0)
	 for (j=i;j < MAX_IPLIST; j++)
	 {
	    if (iplist[j].ip[0] != 0)
	       {
		strcpy(iplist[i].ip, iplist[j].ip);
		iplist[i].traf_in = iplist[j].traf_in;
		iplist[i].traf_out = iplist[j].traf_out;
		iplist[i].overall_in = iplist[j].overall_in;
		iplist[i].overall_out=iplist[j].overall_out;
		iplist[j].ip[0]=0;
		iplist[j].traf_in=0;
		iplist[j].traf_out=0;
		iplist[j].overall_in=0;
		iplist[j].overall_out=0;
		break;
	       }
	 }
   }
  iplistmax = 0;
  for( i=0; i <= MAX_IPLIST; i++)
	 if (iplist[i].ip[0] != 0)
		iplistmax = i;
}
