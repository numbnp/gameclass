// *****************************************************
// *              (C) NodaSoft 2000-2005               *
// *****************************************************

#include "iplist.h"
#include "functions.h"

// reset traffic
void ip_reset(ipliststruct* data)
{
  data->traf_in = 0;
  data->traf_out = 0;
  
  // attribut currently not used
  data->traf_limit = 0;
}

// set limit traffic
void ip_setlimit(ipliststruct* data, long limit)
{
  data->traf_limit = limit;
}

// set speed traffic
void ip_setspeed(ipliststruct* data, long speed)
{
  data->traf_speed = speed;
}

