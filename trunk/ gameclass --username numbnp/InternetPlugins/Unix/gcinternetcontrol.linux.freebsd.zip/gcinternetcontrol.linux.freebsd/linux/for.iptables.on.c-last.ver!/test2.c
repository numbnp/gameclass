#include <stdio.h>
#include "iplist.h"
ipliststruct iplist[MAX_IPLIST]; 	// iplist array
int	iplistmax;			// quantity ip in iplist (count elements in iplist)
char buffer[IN_BUFFER_LEN];		// buffer for udp-packet

void dump_iplist()
{
int i;
printf("iplistmax: %u\n",iplistmax);
printf("Ip\ttraf_in\ttraf_out\tover_in\tover_out\n");
for (i = 0; i <= iplistmax; i++)
    {
//  if (strlen(iplist[i].ip) > 0) 
    printf("%u:\t %s\t %u\t %u\n", i, iplist[i].ip, iplist[i].traf_in, iplist[i].traf_out, iplist[i].overall_in, iplist[i].overall_out);
    }
}



int main(void)
{
int i;

IpListInitialize();
IpListAdd("192.168.10.1");
IpListAdd("192.168.10.2");
IpListAdd("192.168.10.3");
IpListAdd("192.168.10.4");
for (i=0;i<=5;i++) 
    {
    iplist[i].traf_in=(random() % 1024);
    iplist[i].traf_out=(random() % 1024);
    }
dump_iplist();
IpListRemove("192.168.10.2");
IpListDefrag();
dump_iplist();
GenerateAnswerForGameClass();
printf("%s\n",buffer);
usleep(1000);
}


int GenerateAnswerForGameClass()
{
	int i;
	int exist_info;
	char temp_buffer[100];

	// clear buffer
	buffer[0]=0;
	temp_buffer[0]=0;
	// set prefix for GameClass
	strcat(buffer, "v01.inet_get_traffic_value_answer=");

	exist_info = 0;
	for (i=0; i<=iplistmax; i++)
	if (strlen(iplist[i].ip) > 0)
	if ((iplist[i].traf_in > 0) || (iplist[i].traf_out > 0))
	{
		exist_info = 1;
		// add ip
		snprintf(temp_buffer, 100,"%s/%u/%u/",iplist[i].ip ,iplist[i].traf_in, iplist[i].traf_out);
		strcat(buffer, temp_buffer);
	}
	// truncate last "/"
	if (buffer[0] != 0)
    		buffer[strlen(buffer)-1] = 0;
	return exist_info;
}
