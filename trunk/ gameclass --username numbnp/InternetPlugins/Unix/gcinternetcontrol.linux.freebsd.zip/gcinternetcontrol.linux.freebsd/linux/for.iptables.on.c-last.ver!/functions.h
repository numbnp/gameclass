// *****************************************************
// *              (C) NodaSoft 2000-2005               *
// *****************************************************

// services functions

// reset counters traffic
void ip_reset(ipliststruct* data);

// used but not supported on linux, do it manually
void ip_setspeed(ipliststruct* data, long speed);

// currently not used
void ip_setlimit(ipliststruct* data, long limit);

