#include <stdio.h>
#include "iplist.h"
ipliststruct iplist[MAX_IPLIST]; 	// iplist array
int	iplistmax;			// quantity ip in iplist (count elements in iplist)
char buffer[IN_BUFFER_LEN];		// buffer for udp-packet

void dump_iplist()
{
int i;
printf("iplistmax: %d\n",iplistmax);
printf("Ip\ttraf_in\ttraf_out\tover_in\tover_out\n");
for (i = 0; i <= iplistmax; i++)
    {
//  if (strlen(iplist[i].ip) > 0) 
    printf("%d:\t %s\t %ld\t %ld\n", i, iplist[i].ip, iplist[i].traf_in, iplist[i].traf_out, iplist[i].overall_in, iplist[i].overall_out);
    }
}

static char *rnd_ip(void)
{
static char buff[16];
memset(buff,'\0',sizeof(buff));
snprintf(buff, 16,"192.168.10.%u",(random() % 40)+1);
return buff;
}




int main()
{
char command[50];
char ip[16];

IpListInitialize();

unsigned long count = 0;
//IpListAdd("192.168.10.100");
while (1) 
{
count++;
strcpy(ip,rnd_ip());
if ((count % 2) == 0) 
{		//block
snprintf(command, 50,"/etc/gc/template_block %s ",ip);
if (IpListIn(ip))
    {
//    printf("RemoveRule: %s max:%u\n", ip, iplistmax);
//    system(command);
    IpListRemove(ip);
    IpListDefrag();
    }

} else
{		//unblock
snprintf(command, 50,"/etc/gc/template_unblock %s ",ip);
if (!IpListIn(ip))
    {
//    printf("AddRule: %s max:%u\n", ip, iplistmax);
//    system(command);
    IpListAdd(ip);
//    IpListDefrag();
    }
}
dump_iplist();
//printf("Count %lu\n", count);
if (GenerateAnswerForGameClass())
    printf("%s\nCount: %ld=====================================\n",buffer, count);
usleep(1000000);
}//MainCycle

}

int GenerateAnswerForGameClass()
{
	int i;
	int exist_info;
	char temp_buffer[IN_BUFFER_LEN];

	// clear buffer
	buffer[0]=0;
	temp_buffer[0]=0;
	// set prefix for GameClass
	strcat(buffer, "v01.inet_get_traffic_value_answer=");

	exist_info = 0;
	for (i=0; i<=iplistmax; i++)
	if (strlen(iplist[i].ip) > 0)
//	if ((iplist[i].traf_in > 0) || (iplist[i].traf_out > 0))
	{
		exist_info = 1;
		// add ip
		snprintf(temp_buffer, IN_BUFFER_LEN ,"%s/%ld/%ld/",iplist[i].ip ,iplist[i].traf_in, iplist[i].traf_out);
		strcat(buffer, temp_buffer);
	}
	// truncate last "/"
	if (exist_info == 0)
		buffer[0] = 0;
	if (buffer[0] != 0)
    		buffer[strlen(buffer)-1] = 0;
	return exist_info;
}
