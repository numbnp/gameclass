// *****************************************************
// *              (C) NodaSoft 2000-2005               *
// *****************************************************
// *   Traffic Billing Module v 1.0 for GameClass      *
// *   HomePage http://www.nodasoft.com/products/gc    *
// *   Create by NodaSoft                              *
// *   Edition by Tahion, email: tahion at gmail.com   *
// *   a LOT of bugfixes by GoodOne                    *
// *****************************************************

#include <netinet/in.h>                     
#include <sys/socket.h>
#include <stdio.h>
#include "iplist.h"
// Added by Tahion
#include <signal.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <unistd.h>

ipliststruct iplist[MAX_IPLIST]; 	// iplist array
int	iplistmax;			// quantity ip in iplist (count elements in iplist)

char buffer[IN_BUFFER_LEN];		// buffer for udp-packet
char command[COMMAND_BUFFER_LEN];	// string with command for unix
char ip[16];				// ip address
char tarif_name[300];			// tarif_name
struct sockaddr_in local, from;

void GetTrafficInformationFromFirewall();
int GenerateAnswerForGameClass();
void ToSyslog(char *str);
void dump_iplist();
void ToLog(char *str);

        FILE *in;
	char s[20];
	long x,y;
	int i;
	char syslog_buff[200];

// entry point
int main(void)
{
  // ------ socket's variables --------
  int fromlen;
  int listen_socket, msgsock;
  int k=0;
  int fd;
  struct  rlimit  flim;
//  char syslog_buff[20];
 
  /*daemon initialisation part */
  if( getppid() != 1 ){
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    if( fork()!=0 ){
	exit(0);
    }
    setsid();
  }
  getrlimit(RLIMIT_NOFILE, &flim);
  for (fd = 0; fd < flim.rlim_max; fd++)close(fd);
  chdir("/");

  ToSyslog("======= daemon started =======");
  ToLog("======= daemon started =======");

  /*end of daemon initialisation part */
  // DELETING ALL RULES FROM tables
      ToLog("Resetting all rules.");
      strcpy(command,MODULE_PATH);
      strcat(command,"/reset_reject");
      system(command);
/*  
  printf("\n(C) NodaSoft 2000-2005\n");
  printf("(C) Edition by tahion, tahion at gmail.com\n");
  printf("(C) A LOT of bugfixes by GoodOne \n");
  printf("Traffic Billing Module for GameClass is started ...\n");
*/
  
  IpListInitialize();
  ToLog("IpList cleared.");

  // initializing UDP socket
  local.sin_family = AF_INET;
  local.sin_addr.s_addr = htonl(INADDR_ANY);
  local.sin_port = htons(UDP_PORT);

  ToLog("Trying to open listen socket...");
  // can be socket open?
  listen_socket = socket(AF_INET, SOCK_DGRAM,0);
  if (listen_socket == -1) 
  {
    ToSyslog("Error: Socket allready opened !");
    ToLog("Error: Socket allready opened !");
    ToSyslog("Exiting...");
    ToLog("Exiting...");
    exit(1);
  }  
  if (bind(listen_socket,(struct sockaddr*)&local,sizeof(local) ) == -1) 
  {
    ToSyslog("Error: Listen socket error !");
    ToLog("Error: Listen socket error !");
    ToSyslog("Exiting...");
    ToLog("Exiting...");
    exit(1);
  }
  
  // socket open successfully  
  // go working
  ToLog("Entering main programm cycle.");
  while(1) 
  {
    fromlen = sizeof(from);
    msgsock = listen_socket;
    memset(buffer,0,IN_BUFFER_LEN);
//    ToLog("Waiting for UDP Query...");

	// waiting query (UDP-Packet) from GameClass Server
    recvfrom(msgsock,buffer,sizeof(buffer),0,(struct sockaddr *)&from,&fromlen);

//    strncpy(syslog_buff, buffer, 20);
//    snprintf(syslog_buff, sizeof(syslog_buff), "Packet received: [%s...]", syslog_buff);
//    ToLog(syslog_buff);
//    s[0]=0;
    
	// command from server	
	/*********************************************/
    if (strstr(buffer,"inet_block"))
    {
      strcpy(command,MODULE_PATH);
      strcat(command,"/template_block ");
      strcat(command,strstr(buffer,"=")+1);
      strcpy(ip,strstr(buffer,"=")+1);
      if (IpListIn(ip)) 
	  {
        // here is added new Firewall rule (blocking)
	    snprintf(syslog_buff, sizeof(syslog_buff),"Block client: %s command: %s", ip, command);
	    ToSyslog(syslog_buff);
	    ToLog(syslog_buff);
	    system(command);				
	    snprintf(syslog_buff, sizeof(syslog_buff), "IpListRemove(%s)", ip);
	    ToLog(syslog_buff);
	    IpListRemove(ip);
	    snprintf(syslog_buff, sizeof(syslog_buff), "IpListDefrag()",ip);
	    ToLog(syslog_buff);
	    IpListDefrag();
	  }
	} else
    /*********************************************/
    if (strstr(buffer,"inet_unblock"))
    {
      strcpy(command,MODULE_PATH);
      strcat(command,"/template_unblock ");
	  
	  strcpy(tarif_name, "");
	  if (strstr(buffer,"/"))
	  {
		strcpy(tarif_name, strstr(buffer,"/")+1);
		*strstr(buffer,"/")=0;
		strcat(command,strstr(buffer,"=")+1);
		//strcat(command,strstr(tarif_name,"=")+1);
	  }
	  else
	  {
	  strcat(command,strstr(buffer,"=")+1);
	  };
      strcpy(ip,strstr(buffer,"=")+1);
	  
	  // ToDo Exctract second parameter - tarif name
      if (!IpListIn(ip)) 
	  {
// here is removed Firewall rule (unblocking)
	    snprintf(syslog_buff, sizeof(syslog_buff),"Unblock client: %s command: %s", ip, command);
	    ToSyslog(syslog_buff);
	    ToLog(syslog_buff);
	    system(command);
	    snprintf(syslog_buff, sizeof(syslog_buff), "IpListAdd(%s)",ip);
	    ToLog(syslog_buff);
	    IpListAdd(ip);
	  }
    } else
/*********************************************/
//    if (strstr(buffer,"inet_set_speed_for_ip"))
//    {
//		// currently not supported
//    }
/*********************************************/
    if (strstr(buffer,"inet_get_traffic_value"))    
	{
		GetTrafficInformationFromFirewall();
		if (GenerateAnswerForGameClass())
		{
// send answer (using UDP Socket)
//		 printf ("Send UDP %s\n",buffer);
		 snprintf(syslog_buff, sizeof(syslog_buff)," Send UDP %s", buffer);
		 ToSyslog(syslog_buff);		 
		 ToLog(syslog_buff);
		 from.sin_port		 = htons(CG_UDP_PORT);
		 sendto(msgsock,buffer,strlen (buffer),0,(struct sockaddr *)&from,fromlen);
		}
        } else
//	ToLog("Unknown packet. Dropped...");
/*********************************************/
// printf("%s\n",buffer);
/*********************************************/
    dump_iplist();
  }
//  close(listen_socket);
//  return -1;
}

// return 1, if exist info for >0 ip's, else return 0
int GenerateAnswerForGameClass()
{
	int i;
	int exist_info;
	char temp_buffer[IN_BUFFER_LEN];

	// clear buffer
	buffer[0]=0;
	temp_buffer[0]=0;
	// set prefix for GameClass
	strcat(buffer, "v01.inet_get_traffic_value_answer=");

	exist_info = 0;
	for (i=0; i<=iplistmax; i++)
	if (strlen(iplist[i].ip) > 0)
	if ((iplist[i].traf_in > 0) || (iplist[i].traf_out > 0))
	{
		exist_info = 1;
		// add ip
		snprintf(temp_buffer, IN_BUFFER_LEN ,"%s/%u/%u/",iplist[i].ip ,iplist[i].traf_in, iplist[i].traf_out);
		strcat(buffer, temp_buffer);
		iplist[i].traf_in=0;
		iplist[i].traf_out=0;
	}
	// truncate last "/"
	if (exist_info == 0)
		buffer[0] = 0;
	if (buffer[0] != 0)
    		buffer[strlen(buffer)-1] = 0;
	return exist_info;
}






// this function retrieve data from linux firewall, parse this data and put to 
// iplist array
void GetTrafficInformationFromFirewall()
{
	strcpy(command,MODULE_PATH);
	strcat(command,"/get_traf >/tmp/input_file");
	system(command);
// run command and receive results from linux (from iptables)
	in = fopen("/tmp/input_file","r");

   	while (!feof(in))
   	{
   	if ((fscanf(in,"%s %d %d",s,&x,&y)) == 3)
   	 {
	 	for (i=0; i<=iplistmax; i++)
		{
			if (strcmp(iplist[i].ip,s)==0)
		 	{ 
			  iplist[i].traf_in    +=y;
			  iplist[i].traf_out   +=x;
			  iplist[i].overall_in +=y;
			  iplist[i].overall_out+=x;
			  break;
			}
		};
	 };
   	};

	fclose(in);
//	in = fopen("/tmp/input_file","w");
//	fclose(in);
	// parse results and put it to iplist array
}


void ToSyslog(char *str)
{
  openlog("gctb", LOG_PID | LOG_CONS, LOG_DAEMON);
  syslog(LOG_INFO,str);
  closelog();
}


void dump_iplist()
{
int i;
FILE *dump;
if ((dump = fopen("/tmp/dump_iplist","w")) == NULL) 
    return;
fprintf(dump, "Ip\ttraf_in\ttraf_out\toverall_in\toverall_out\n");
if (iplistmax > 0)
for (i = 0; i <= iplistmax; i++)
    {
//    if (strlen(iplist[i].ip) > 0) 
	fprintf(dump, "%d:\t %s\t %ld\t %ld\n", i, iplist[i].ip, iplist[i].traf_in, iplist[i].traf_out, iplist[i].overall_in, iplist[i].overall_out);
    }
fflush(dump);
fclose(dump);
}

void ToLog(char *str)
{
FILE *log;
time_t now;
struct tm *l_time;
char string[20];
struct timeval tv;
struct timezone tz;
if ((log = fopen("/var/log/gctb.log","a")) == NULL) 
	return;
time(&now);
gettimeofday(&tv, &tz);
l_time = localtime(&now);
strftime(string, sizeof string, "%d/%b/%y %H:%M:%S", l_time);
fprintf(log, "%s.%03lu: %s\n", string,(tv.tv_usec /1000),str);
fflush(log);
fclose(log);
}
