#============================================================================
# raVen's text package
# $Id: text.pm,v 1.27 2005/03/15 14:20:48 raven Exp $
# (c) 2k2-4 by raVen
# ���� ����� ����� ������� � koi8-r :-)
#============================================================================
package raven::text;
use strict;
use vars qw(@EXPORT @ISA);
require Exporter;
@ISA = qw(Exporter);
#----------------------------------------------------------------------------
our @week_days = (
 '�����������',
 '�����������',
 '�������',
 '�����',
 '�������',
 '�������',
 '�������'
);
#----------------------------------------------------------------------------
our @month_names = (
 '������',
 '�������',
 '����',
 '������',
 '���',
 '����',
 '����',
 '������',
 '��������',
 '�������',
 '������',
 '�������'
);
our $mangle_table = {
 '�' => 'y',
 '�' => 'Y',
 '�' => 'K',
 '�' => 'e',
 '�' => 'E',
 '�' => 'H',
 '�' => 'W',
 '�' => 'w',
 '�' => '3',
 '�' => 'X',
 '�' => 'x',
 '�' => 'B',
 '�' => 'b',
 '�' => 'A',
 '�' => 'a',
 '�' => 'P',
 '�' => 'p',
 '�' => 'O',
 '�' => 'o',
 '�' => 'C',
 '�' => 'c',
 '�' => 'M',
 '�' => 'm',
 '�' => 'T',
 'y' => '�',
 'Y' => '�',
 'K' => '�',
 'e' => '�',
 'E' => '�',
 'H' => '�',
 'W' => '�',
 'w' => '�',
 '3' => '�',
 'X' => '�',
 'x' => '�',
 'B' => '�',
 'b' => '�',
 'A' => '�',
 'a' => '�',
 'P' => '�',
 'p' => '�',
 'O' => '�',
 'o' => '�',
 'C' => '�',
 'c' => '�',
 'M' => '�',
 'm' => '�',
 'T' => '�',
};
#----------------------------------------------------------------------------
our $ip_addr_mask = '\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}';
our $ip_addr_mask3 = '(\d{1,3}\.\d{1,3}\.\d{1,3})\.\d{1,3}';
#============================================================================
# $string = validate_uri($re, $string):
#----------------------------------------------------------------------------
sub validate_uri($$) {
 my $re = shift();
 my $string = shift();
 my $res = '';
 for my $index(0 .. length($string) - 1) {
  my $char = substr($string, $index, 1);
  $char = sprintf('%%%02x', unpack('C', $char)) unless ($char =~ /$re/i);
  $res .= $char;
 }
 return($res);
}
#============================================================================
# $text = koi2win($text);
#----------------------------------------------------------------------------
sub koi2win($) {
 my $str = shift();
 return('') unless($str);
 $str =~ tr/\xA3\xB3\xC0-\xFF/\xB8\xA8\xFE\xE0\xE1\xF6\xE4\xE5\xF4\xE3\xF5\xE8-\xEF\xFF\xF0-\xF3\xE6\xE2\xFC\xFB\xE7\xF8\xFD\xF9\xF7\xFA\xDE\xC0\xC1\xD6\xC4\xC5\xD4\xC3\xD5\xC8-\xCF\xDF\xD0-\xD3\xC6\xC2\xDC\xDB\xC7\xD8\xDD\xD9\xD7\xDA/;
 return($str);
}
#============================================================================
# $text = win2koi($text);
#----------------------------------------------------------------------------
sub win2koi($) {
 my $str = shift();
 return('') unless($str);
 $str =~ tr/\xB8\xA8\xFE\xE0\xE1\xF6\xE4\xE5\xF4\xE3\xF5\xE8-\xEF\xFF\xF0-\xF3\xE6\xE2\xFC\xFB\xE7\xF8\xFD\xF9\xF7\xFA\xDE\xC0\xC1\xD6\xC4\xC5\xD4\xC3\xD5\xC8-\xCF\xDF\xD0-\xD3\xC6\xC2\xDC\xDB\xC7\xD8\xDD\xD9\xD7\xDA/\xA3\xB3\xC0-\xFF/;
 return($str);
}
#============================================================================
# $text = win2dos($text);
#----------------------------------------------------------------------------
sub win2dos($) {
 my $str = shift();
 return('') unless($str);
 $str =~ tr/\xa8\xb8\xc0-\xef\xf0-\xff/\xf0\xf1\x80-\xaf\xe0-\xef/;
 return($str);
}
#============================================================================
# $text = dos2win($text);
#----------------------------------------------------------------------------
sub dos2win($) {
 my $str = shift();
 return('') unless($str);
 $str =~ tr/\xf0\xf1\x80-\xaf\xe0-\xef/\xa8\xb8\xc0-\xef\xf0-\xff/;
 return($str);
}
#============================================================================
# $text = remove_mat($codepage, $change, $text);
#----------------------------------------------------------------------------
sub remove_mat($$$) {
 use POSIX qw(locale_h);
 use Lingua::RU::Antimat;
 use locale;
 setlocale(LC_CTYPE, 'ru_RU.KOI8-R');
 my $mat = Lingua::RU::Antimat->new(shift());
 $mat->set_bip(shift());
 my $result = $mat->remove_slang(' ' . shift() . ' ');
 no locale;
 return(substr($result, 1, length($result) - 2));
}
#============================================================================
# $text = detect_mat($codepage, $text);
#----------------------------------------------------------------------------
sub detect_mat($$) {
 use POSIX qw(locale_h);
 use Lingua::RU::Antimat;
 use locale;
 setlocale(LC_CTYPE, 'ru_RU.KOI8-R');
 my $mat = Lingua::RU::Antimat->new(shift());
 my $result = $mat->detect_slang(' ' . shift() . ' ');
 $result = 0 if ($result eq '');
 no locale;
 return($result);
}
#============================================================================
# $text = extract_thousands($text[, $separator]);
#----------------------------------------------------------------------------
sub extract_thousands {
 local $_  = shift;
 my $separator = shift();
 $separator = ' ' unless (defined($separator));
 return(undef) unless (defined($_));
 1 while s/^([-+]?\d+)(\d{3})/$1$separator$2/;
 return $_;
}
#============================================================================
# $text = num_to_size($number, $maxlen);
#============================================================================
sub num_to_size($$) {
 my @ss = ('b', 'Kb', 'Mb', 'Gb', 'Tb');
 my $number = shift();
 my $maxlen = shift();
 my $counter = 0;
 my $res = $number . $ss[$counter++];
 while ((abs(length($res) - $maxlen) > 0) && (sprintf('%0.0f', $number / 1024) != 0)) {
  $number = $number / 1024;
  $number = sprintf('%0.0f', $number);
  $res = $number . $ss[$counter++];
 }
 return($res);
}
#============================================================================
# $number = num_to_size($text);
#============================================================================
sub size_to_num($) {
 my $input = shift();
 my $output = 0;
 if ($input =~ /^\s*([\d\.]+)\s*([kmgt])b?\s*$/i) {
  $output = $1;
  my $char = lc($2);
  if ($char eq 'k') {
   $output *= 1024;
  } elsif ($char eq 'm') {
   $output *= 1048576;
  } elsif ($char eq 'g') {
   $output *= 1073741824;
  } elsif ($char eq 't') {
   $output *= 1099511627776;
  }
 }
 return($output);
}
#============================================================================
sub get_path_name($) {
 my @ary = split(/\//, shift());
 pop(@ary);
 return(join('/', @ary));
}
#============================================================================
sub add_back_slash($) {
 my $path = shift();
 return('') if ($path eq '');
 $path = "$path/" if (substr($path, length($path) - 2, 1) ne '/');
 return($path);
}
#============================================================================
sub remove_back_slash($) {
 my $path = shift();
 $path = substr($path, 0, length($path) - 1) if (substr($path, length($path) - 1, 1) eq '/');
 return($path);
}
#============================================================================
sub just_path_name($) {
 my @folders = split(/\//, shift());
 pop(@folders);
 return(join('/', @folders));
}
#============================================================================
sub just_file_name($) {
 my $string = shift();
 return('') if (substr($string, length($string) - 1, 1) eq '/');
 my @folders = split(/[\\\/]/, $string);
 return(pop(@folders));
}
#============================================================================
sub just_extension($) {
 my @folders = split(/\./, just_file_name(shift()));
 return('') if ($#folders == 0);
 return(pop(@folders));
}
#============================================================================
sub just_name($) {
 my @folders = split(/\./, just_file_name(shift()));
 pop(@folders) if ($#folders > 0);
 return(join('.', @folders));
}
#============================================================================
# log_print($file_name, $string);
#============================================================================
sub log_print($$) {
 my $log_name = shift();
 my $line = shift();
 $line .= "\n" unless ($line =~ /[\n\r]$/);
 my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time());
 $year = $year % 100; $mon++;
 open(LOG, ">>$log_name") or return();
 print(LOG sprintf("%02d/%02d/%02d, %02d:%02d:%02d ", $mday, $mon, $year, $hour, $min, $sec) . $line);
 close(LOG);
}
#============================================================================
# $integer = trunc($real);
#----------------------------------------------------------------------------
sub trunc($) {
 $_ = shift();
 return(0) unless /^\-?\d*(\.\d+)?$/;
 s/\.\d+//;
 return($_);
}
#============================================================================
# $integer = round($real);
#----------------------------------------------------------------------------
sub round($) {
 $_ = shift();
 return(0) unless /^\-?\d*(\.\d+)?$/;
 return(sprintf('%0.0f', $_));
}
#============================================================================
# $string = trim_all($string);
#----------------------------------------------------------------------------
sub trim_all($) {
 my $string = shift();
 return('') unless($string);
 $string =~ s/^\s+//;
 $string =~ s/\s+$//;
 return($string);
}
#============================================================================
# $string = trim_all_chars($string, $chars);
#----------------------------------------------------------------------------
sub trim_all_chars($$) {
 my($string, $chars) = (shift(), shift());
 return('') unless($string);
 $string =~ s/^[\Q$chars\E]+//;
 $string =~ s/[\Q$chars\E]+$//;
 return($string);
}
#============================================================================
# clean_str($text);
#----------------------------------------------------------------------------
sub clean_str($) {
 $_[0] =~ s/\>[\n\r]+[\x09\x20]+/\> /g;
 $_[0] =~ s/[\n\r]+[\x09\x20]+/ /g;
 $_[0] =~ s/[\x09\x20]+[\n\r]+/ /g;
 $_[0] =~ s/[\n\r]+/ /g;
 $_[0] =~ s/[\x09\x20]+/ /g;
 $_[0] =~ s/\<\!\-\-.+?\-\-\>//g;
}
#============================================================================
# process_string_by_macros($string, $macro, $replace)
#----------------------------------------------------------------------------
sub process_string_by_macros($$$) {
 return() unless (defined($_[0])) and (defined($_[1])) and (defined($_[2]));
 # ���� �� ������������, �� ������ �� ������:
 $_[0] =~ s/([^\\])\$$_[1]/$1$_[2]/ig;
 # ���� ������ ������, �� ������ �� ������:
 $_[0] =~ s/^\$$_[1]/$_[2]/ig;
 # ���� ������������, �� ������� �������������:
 $_[0] =~ s/\\(\$$_[1])/$1/ig;
}
#============================================================================
# $string = random_mangle_letters($string)
#----------------------------------------------------------------------------
sub random_mangle_letters($) {
 my $string = shift();
 return(undef) unless(defined($string));
 foreach my $i(0 .. length($string) - 1) {
  if(
   (rand(11) >= 5) and
   (exists($mangle_table->{substr($string, $i, 1)}))
  ) {
   substr($string, $i, 1) = $mangle_table->{substr($string, $i, 1)}
  }
 }
 return($string);
}
#============================================================================
# �������������� ������� �����, ��� ����� ����
# (�) Andrey Sapozhnikov, sapa@icb.chel.su
{
 no strict "refs";
 @EXPORT = map {
  local $SIG{__WARN__} = sub { die @_ };
  my $gref = ${'main::' . __PACKAGE__ . '::'}{$_};
  /^[^a-z]|^isa$/ ? () : (
   ((*$gref{CODE}) ? ($_) : ()) ,
   ((*$gref{HASH}) ? ("%$_") : ()) ,
   ((*$gref{ARRAY}) ? "\@$_" : ()) ,
   ( !/^[ab]$/ && (eval('use strict; $' . $_), !$@) ? "\$$_" : ())
  )
 } keys %{'main::' . __PACKAGE__ . '::'};
}
#============================================================================
1;
__END__

=head1 NAME

raven::text - raVen's text functions

=head1 SYNOPSIS

use raven::text;

=head1 DESCRIPTION

function list:

=over

=item $text = koi2win($text);

recode from koi to win

=item $text = win2koi($text);

recode from win to koi

=item $text = remove_mat($codepage, $change, $text);

remove ma� from $text

=item $text = detect_mat($codepage, $change, $text);

detect mat in $text

=item $text = extract_thousands($text);

1234567 -> 1 234 567

=back

=head1 SEE ALSO

hellcome to http://raven.elk.ru

=head1 AUTHOR

Dmitry Suhodoev, http://raven.elk.ru

=head1 QOPYRIGHT

(q) 2k2-4 by raVen

=cut
