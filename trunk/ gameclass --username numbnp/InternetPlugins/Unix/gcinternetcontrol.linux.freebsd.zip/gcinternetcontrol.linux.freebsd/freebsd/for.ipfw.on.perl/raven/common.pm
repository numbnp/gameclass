#============================================================================
# raVen's common package
# $Id: common.pm,v 1.10 2004/07/21 07:30:43 raven Exp $
# (c) 2k2-4 by raVen
# ���� ����� ����� ������� � koi8-r :-)
#============================================================================
package raven::common;
use strict;
use vars qw(@EXPORT @ISA);
require Exporter;
@ISA = qw(Exporter);
our $stderr;
#============================================================================
# $byte=calc_crc8($data);
#----------------------------------------------------------------------------
sub calc_crc8($) {
 sub upd_crc8 {
  my $crc8 = shift();
  my $v = shift();
  for(my $i = 0; $i < 8; $i++) {
   if (($crc8 ^ ord($v)) & 128) {
    $crc8 = ($crc8 << 1) ^ 0xb4;
   } else {
    $crc8 = $crc8 << 1;
   }
   $v = chr(ord($v) << 1);
  }
  return($crc8);
 }
 my $len = length(my $data = shift());
 my $crc8 = 0;
 for(my $i = 0; $i < $len; $i++) {
  $crc8 = upd_crc8($crc8, substr($data, $i, 1));
  $crc8 &= 255;
 }
 return($crc8);
}
#============================================================================
# $string = get_loc();
#----------------------------------------------------------------------------
sub get_loc() {
 my @call = caller();
 return("$call[1]#$call[2]");
}
#============================================================================
# $string = get_exe_name();
#----------------------------------------------------------------------------
sub get_exe_name() {
 return($0);
}
#============================================================================
# $boolean = check_prog_by_pid($pid_file_name);
#----------------------------------------------------------------------------
sub check_prog_by_pid($) {
 my $pid = shift();
 kill(0, $pid) and return($pid);
 return(0);
}
#============================================================================
# $boolean = check_prog_by_pid_file($pid);
#----------------------------------------------------------------------------
sub check_prog_by_pid_file($) {
 my $SEMA = shift();
 if (open(SEMA, "<$SEMA")) {
  chop(my $pid = <SEMA>);
  close(SEMA);
  kill(0, $pid) and return($pid);
 }
 return(0);
}
#============================================================================
# shut_stderr();
#----------------------------------------------------------------------------
sub shut_stderr() {
 return() if (defined($stderr));
 open($stderr, ">&STDERR");
 close(STDERR);
 open(STDERR, '>/dev/null');
}
#============================================================================
# retn_stderr();
#----------------------------------------------------------------------------
sub retn_stderr() {
 return() unless (defined($stderr));
 close(STDERR);
 {
  local *TEMP = $stderr;
  open(STDERR, '>&TEMP');
  undef(*TEMP);
 }
 close($stderr);
 undef($stderr);
}
#============================================================================
# �������������� ������� �����, ��� ����� ����
# (�) Andrey Sapozhnikov, sapa@icb.chel.su
{
 no strict "refs";
 @EXPORT = map {
  local $SIG{__WARN__} = sub { die @_ };
  my $gref = ${'main::' . __PACKAGE__ . '::'}{$_};
  /^[^a-z]|^isa$/ ? () : (
   ((*$gref{CODE}) ? ($_) : ()) ,
   ((*$gref{HASH}) ? ("%$_") : ()) ,
   ((*$gref{ARRAY}) ? "\@$_" : ()) ,
   ( !/^[ab]$/ && (eval('use strict; $' . $_), !$@) ? "\$$_" : ())
  )
 } keys %{'main::' . __PACKAGE__ . '::'};
}
#============================================================================
1;

__END__


=head1 NAME

raven::common - raVen's common functions

=head1 SYNOPSIS

use raven::common;

=head1 DESCRIPTION

function list:

=over

=item $byte=calc_crc8($data);

calculates crc8 of $data

=back

=head1 SEE ALSO

hellcome to http://raven.elk.ru

=head1 AUTHOR

Dmitry Suhodoev, http://raven.elk.ru

=head1 QOPYRIGHT

(q) 2k2-4 by raVen

=cut
