#!/bin/sh
#
# $Id: gcinet.sh,v 1.2 2005/03/11 15:51:10 raven Exp $
#

# PROVIDE: gcinet
# REQUIRE: LOGIN
# KEYWORD: FreeBSD shutdown

#
# Add the following line to /etc/rc.conf to enable gcinet:
#
#gcinet_enable="YES"
#
# For IPv4 only operation add the following line to /etc/rc.conf:
#
#gcinet_flags="-6"
#

. /usr/local/etc/rc.subr

name=gcinet
rcvar=`set_rcvar`

extra_commands="reload"

command=/usr/local/raven/icafe/gcinet/gcinet.pl

gcinet_enable=${gcinet_enable:-"NO"}
gcinet_flags=${gcinet_flags:-""}

load_rc_config ${name}
run_rc_command "$1"
