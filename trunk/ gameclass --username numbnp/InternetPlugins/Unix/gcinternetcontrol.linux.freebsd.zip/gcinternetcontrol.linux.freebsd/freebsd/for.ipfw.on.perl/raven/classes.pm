#============================================================================
# raVen's classes package
# $Id: classes.pm,v 1.7 2005/03/15 15:10:29 raven Exp $
# (c) 2k2-4 by raVen
# ���� ����� ����� ������� � koi8-r :-)
#============================================================================

{
 package raven::html::table;
 use strict;
 use raven::text;

 # todo:
 #  - none;

 sub new {
  my $class  = shift();
  $class = ref($class) || $class;
  my $options = shift();
  my $self = {
   'debug_info'		=> $options->{'debug_info'} || 0,
   'columns'		=> $options->{'columns'} || 1,
   'columns_padding'	=> $options->{'columns_padding'} || 5,
   'tag_table_b'	=> $options->{'tag_table_b'} || '<table>',
   'tag_table_e'	=> $options->{'tag_table_e'} || '</table>',
   'tag_tr_h_b'		=> $options->{'tag_tr_h_b'} || '<th>',
   'tag_tr_h_e'		=> $options->{'tag_tr_h_e'} || '</th>',
   'tag_td_h_b'		=> $options->{'tag_td_h_b'} || '<td>',
   'tag_td_h_e'		=> $options->{'tag_td_h_e'} || '</td>',
   'desc_sort'		=> $options->{'desc_sort'} || '&laquo;',
   'asc_sort'		=> $options->{'asc_sort'} || '&raquo;',
   'tag_tr_b'		=> $options->{'tag_tr_b'} || '<tr>',
   'tag_tr_e'		=> $options->{'tag_tr_e'} || '</tr>',
   'tag_td_b'		=> $options->{'tag_td_b'} || '<td>',
   'tag_td_e'		=> $options->{'tag_td_e'} || '</td>',
   'table_data'		=> $options->{'table_data'} || undef,
   'sort_order'		=> $options->{'sort_order'} || '',
   'header_tpl'		=> $options->{'header_tpl'} || undef,
   'data_tpl'		=> $options->{'data_tpl'} || undef
  };
  $self->{'columns'} = 1 if ($self->{'columns'} < 1);

  bless($self, $class);
  return($self);
 }

 sub debug_info {
  my $self  = shift();
  $self->{'debug_info'} = shift() if (@_);
  return($self->{'debug_info'});
 }

 sub table_data {
  my $self  = shift();
  $self->{'table_data'} = shift() if (@_);
  return($self->{'table_data'});
 }

 sub sort_order {
  my $self  = shift();
  $self->{'sort_order'} = shift() if (@_);
  return($self->{'sort_order'});
 }

 sub get_html {
  my $self  = shift();
  my $html = '';

  my $row_total = $#{$self->{'table_data'}->{'data'}} + 1;
  my $row_processed = 0;
  my $columns_rest = $self->{'columns'};
  $html .= qq~
   <table border="0" cellspacing="0" cellpadding="$self->{'columns_padding'}"><tr>~;
  for my $column_index(1 .. $self->{'columns'}) {
   $html .= qq~
    <td valign="top">
     $self->{'tag_table_b'}
      $self->{'tag_tr_h_b'}~;

   my %column = ();
   my($sort_order, $sort_seq) = split(/,/, $self->{'sort_order'});
   $sort_order = '' unless(defined($sort_order));
   $sort_seq = 'asc' unless(defined($sort_seq));
   my $sort_index_founded = -1;
   $sort_seq = 'asc' unless(defined($sort_seq));

   for my $index(0 .. $#{$self->{'table_data'}->{'headers'}}) {
    my $column_hash = $self->{'table_data'}->{'headers'}->[$index];
    my $new_sort_seq = ',asc';
    my $header_sort_order = '';
    if ($column_hash->[0] eq $sort_order) {
     $sort_index_founded = $index;
     if ($sort_seq eq 'asc') {
      $new_sort_seq = ',desc';
      $header_sort_order = $self->{'asc_sort'};
     } else {
      $header_sort_order = $self->{'desc_sort'};
     }
    }
    my $header_tpl = $self->{'header_tpl'};
    process_string_by_macros($header_tpl, 'header_id', $column_hash->[0] . $new_sort_seq);
    process_string_by_macros($header_tpl, 'header_comment', $column_hash->[1]);
    process_string_by_macros($header_tpl, 'header_sort_order', $header_sort_order);
    $html .= qq~
       $self->{'tag_td_h_b'}$header_tpl$self->{'tag_td_h_e'}~;
   }
   $sort_index_founded = 0 if ($sort_index_founded == -1);

   $html .= qq~
      $self->{'tag_tr_h_e'}~;

   my $row_count = $row_total / $columns_rest--;
   if (index($row_count, '.') >= 0) {
    $row_count = int($row_count) + 1;
   } else {
    $row_count = int($row_count);
   }
   $row_total -= $row_count;
   foreach my $main_column_id_index($row_processed .. $row_processed + $row_count - 1) {
    my $main_column_id = $self->{'table_data'}->{'data'}->[$main_column_id_index]->[0];
    $html .= qq~
      $self->{'tag_tr_b'}~;
    for my $index(1 .. $#{$self->{'table_data'}->{'data'}->[$main_column_id_index]}) {
     my $column_data = $self->{'table_data'}->{'data'}->[$main_column_id_index]->[$index];
     my $data_tpl = $self->{'data_tpl'};
     process_string_by_macros($data_tpl, 'data_id', $main_column_id);
     process_string_by_macros($data_tpl, 'data_comment', $column_data);
     $html .= qq~
       $self->{'tag_td_b'}$data_tpl$self->{'tag_td_e'}~;
    }
    $html .= qq~
      $self->{'tag_tr_e'}~;
   }
   $row_processed += $row_count;

   $html .= qq~
     $self->{'tag_table_e'}
    </td>~;

   last if ($row_total <= 0);
  }

  $html .= qq~
   </tr></table>~;
  clean_str($html) unless $self->{'debug_info'};
  return(\$html);

 }

 sub DESTROY {
 }
}

#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================

{
 package raven::text::gen;
 use raven::text;

 # constructor
 sub new {
  my $class  = shift();
  $class = ref($class) || $class;
  my $options = shift();
  my $self = {};
  $self = {
   'text'		=> $options->{'text'} || '',
   'macros'		=> $options->{'macros'} || undef,
  };
  bless($self, $class);
  return($self);
 }

 # methods
 sub get_gen {
  my $self  = shift();
  $self->{'text'} = shift() if (@_);
  my $text = $self->{'text'};
  my %repl_hash = ();
  foreach my $find(keys %{$self->{'macros'}}) {
   my $repl = '';
   do {
    $repl = $self->{'macros'}->{"$find"}->[rand($#{$self->{'macros'}->{"$find"}}+1)]
   } while(exists($repl_hash{"$repl"}));
   process_string_by_macros($text, $find, $repl);
   $repl_hash{"$repl"} = 1;
  }
  return($text);
 }

 # data
 sub a_text {
  my $self  = shift();
  $self->{'text'} = shift() if (@_);
  return($self->{'text'});
 }

 sub add_macro {
  my $self = shift();
  my $find = shift();
  my $replace = shift();
  $self->{'macros'}->{"$find"} = [] unless (exists($self->{'macros'}->{"$find"}));
  push(@{$self->{'macros'}->{"$find"}}, $replace);
 }

 sub remove_macro {
  my $self  = shift();
  my $find = shift();
  my $replace = shift();
  if (exists($self->{'macros'}->{'find'})) {
   @{$self->{'macros'}->{'find'}} = grep($_ ne $replace, @{$self->{'macros'}->{'find'}});
  }
 }

 sub add_macro_mirror {
  my $self = shift();
  my $find = shift();
  my $mirror = shift();
  $self->{'macros'}->{"$mirror"} = [] unless (exists($self->{'macros'}->{"$mirror"}));
  $self->{'macros'}->{"$find"} = $self->{'macros'}->{"$mirror"};
 }

 # destructor
 sub DESTROY {
 }
}

#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================

{
 package raven::web::poster;
 use LWP;
 use LWP::UserAgent;
 use HTTP::Request;
 use HTTP::Request::Common;
 use HTTP::Cookies;
 use raven::text;

 # constructor
 sub new {
  my $class  = shift();
  $class = ref($class) || $class;
  my $options = shift();
  my $self = {};
  $self = {
   'fields'		=> $options->{'fields'} || {},
   'proxy'		=> $options->{'proxy'} || undef,
  };
  bless($self, $class);
  return($self);
 }

 # data
 sub add_field {
  my $self  = shift();
  my($name, $value) = @_;
  return() unless(defined($name) and (defined($value)));
  $self->{'fields'}->{"$name"} = $value;
 }

 sub remove_field {
  my $self  = shift();
  my $name = shift();
  return() unless(defined($name));
  delete($self->{'fields'}->{"$name"});
 }

 sub remove_all {
  my $self  = shift();
  $self->{'fields'} = {};
 }

 sub a_fields {
  my $self  = shift();
  $self->{'fields'} = shift() if (@_);
  return($self->{'fields'});
 }

 sub a_proxy {
  my $self  = shift();
  $self->{'proxy'} = shift() if (@_);
  return($self->{'proxy'});
 }

 # methods
 sub post {
  my $self  = shift();
  my $uri = shift();
  my $request = POST($uri, $self->{'fields'});
  my $ua = LWP::UserAgent->new();
  $ua->proxy('http', $self->{'proxy'}) if(defined($self->{'proxy'}));
  my $response = $ua->request($request);
  if ($response->is_redirect()) {
   $request = GET(just_path_name($response->base()) . '/' . $response->{'_headers'}->{'location'});
   $response = $ua->request($request);
  }
  if ($response->is_success()) {
   return($response->content())
  } else {
   return(undef);
  }
 }

 # destructor
 sub DESTROY {
 }
}

#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================
#============================================================================

{
 package raven::proxy::checker;
 use LWP;
 use LWP::UserAgent;
 use HTTP::Request;
 use HTTP::Request::Common;
 use HTTP::Cookies;

 # constructor
 sub new {
  my $class  = shift();
  $class = ref($class) || $class;
  my $options = shift();
  my $self = {};
  $self = {
   'addr'		=> $options->{'addr'} || undef,
   'uri'		=> $options->{'uri'} || 'http://www.ru',
  };
  bless($self, $class);
  return($self);
 }

 # data
 sub a_addr {
  my $self  = shift();
  $self->{'addr'} = shift() if (@_);
  return($self->{'addr'});
 }

 sub a_uri {
  my $self  = shift();
  $self->{'uri'} = shift() if (@_);
  return($self->{'uri'});
 }

 # methods
 sub online {
  my $self  = shift();
  $self->{'addr'} = shift() if (@_);
  $self->{'uri'} = shift() if (@_);
  my $request = GET($self->{'uri'});
  my $ua = LWP::UserAgent->new();
  my $response = $ua->request($request);
  my $no_proxy_response = $response->content();
  $no_proxy_response = 'no_proxy_response' unless(defined($no_proxy_response));

  $ua->timeout(60);
  $ua->proxy('http', $self->{'addr'});
  $response = $ua->request($request);
  my $proxy_response = $response->content();
  $proxy_response = 'proxy_response' unless(defined($proxy_response));

  return(($no_proxy_response eq $proxy_response) and ($proxy_response ne ''));
 }

 # destructor
 sub DESTROY {
 }
}

1;

__END__


=head1 NAME

raven::classes - raVen's classes

=head1 SYNOPSIS

use raven::classes;

=head1 DESCRIPTION

classes list:

=over

=back

=head1 SEE ALSO

hellcome to http://raven.elk.ru

=head1 AUTHOR

Dmitry Suhodoev, http://raven.elk.ru

=head1 QOPYRIGHT

(q) 2k2-4 by raVen

=cut
