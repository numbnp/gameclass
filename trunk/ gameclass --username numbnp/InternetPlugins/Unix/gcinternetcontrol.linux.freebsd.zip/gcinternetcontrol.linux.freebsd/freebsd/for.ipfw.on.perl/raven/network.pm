#============================================================================
# raVen's network package
# $Id: network.pm,v 1.11 2005/03/09 15:01:21 raven Exp $
# (c) 2k2-4 by raVen
# ���� ����� ����� ������� � koi8-r :-)
#============================================================================
package raven::network;
use strict;
use raven::text;
use raven::common;
use vars qw(@EXPORT @ISA);
require Exporter;
@ISA = qw(Exporter);
#============================================================================
# $addr=name2addr($hostname);
#----------------------------------------------------------------------------
sub name2addr($) {
 use Net::DNS;
 my $hostname = shift();
 return(undef) unless(defined($hostname));
 my $res = Net::DNS::Resolver->new();
 my $query = $res->search($hostname);
 if ($query) {
  foreach my $rr ($query->answer()) {
   next() unless($rr->type() eq 'A');
   return($rr->address());
  }
 } else {
  return(undef);
 }
}
#============================================================================
# $if_name=ifconfig_get_if_by_ip($ip_addr, $first);
#----------------------------------------------------------------------------
sub ifconfig_get_if_by_ip {
 my $ip_addr = shift();
 my $first = shift() || 0;
 my $ip_addr3 = '';
 if($ip_addr =~ $ip_addr_mask3) {
  $ip_addr3 = $1;
 } else {
  return('');
 }
 open(IFCONFIG, "/sbin/ifconfig -a 2>&1 |");
 my $if = '';
 my $result = '';
 while(<IFCONFIG>) {
  $if = $1 if(/(^.+)\:\sflags\=/);
  if(/inet $ip_addr_mask3 \-\-\> ($ip_addr_mask)/i) {
   if($ip_addr eq $2) {
    $result = $if;
    last() if($first);
   }
  }
  if(/inet $ip_addr_mask3 netmask .+ broadcast $ip_addr_mask/i) {
   if($ip_addr3 eq $1) {
    $result = $if;
    last() if($first);
   }
  }
 }
 close(IFCONFIG);
 return($result);
}
#============================================================================
# $byte=send_message($ip:port,$password,$header,$text,$attr);
#----------------------------------------------------------------------------
sub send_message($$$$$) {
 use Socket;
 use IO::Handle;
 use String::CRC32;
 use Digest::MD5 qw(md5_hex);

 my($host, $port) = split(/\:/,shift());
 my $password = shift();
 my $header = koi2win(shift());
 my $text = koi2win(shift());
 my $utype = shift();

 my $buf = "12 p=".uc(md5_hex($password)) . "\0$header\0$text\0$utype\0";
 my $len = length($buf);

 my $crc32 = String::CRC32::crc32($buf,-1);

 my $init_buf = sprintf("%c%c%c%c%c%c%c\0\0\0\0\0\0\0\0",
  ((($len << 16) >> 16) & 255),
  ((($len << 8) >> 16) & 255),
  ((($len << 0) >> 16) & 255),
  ((($crc32 << 24) >> 24) & 255),
  ((($crc32 << 16) >> 24) & 255),
  ((($crc32 << 8) >> 24) & 255),
  ((($crc32 << 0) >> 24) & 255)
 );

 $init_buf = chr(calc_crc8($init_buf)) . $init_buf;

 my $protocol = getprotobyname('tcp');
 $host = inet_aton($host) or return(1);
 socket(SOCK, AF_INET, SOCK_STREAM, $protocol) or return(2);
 my $dest_addr = sockaddr_in($port, $host);
 connect(SOCK, $dest_addr) or return(3);
 SOCK->autoflush(1);

 print(SOCK $init_buf);
 print(SOCK $buf);
# my($answer)=<SOCK>;
# print("$answer\n") if (defined($answer));

 close(SOCK);
 return(0);
}
#============================================================================
# ��⮬���᪨� ��ᯮ�� �ᥣ�, �� ����� ����
# (�) Andrey Sapozhnikov, sapa@icb.chel.su
{
 no strict "refs";
 @EXPORT = map {
  local $SIG{__WARN__} = sub { die @_ };
  my $gref = ${'main::' . __PACKAGE__ . '::'}{$_};
  /^[^a-z]|^isa$/ ? () : (
   ((*$gref{CODE}) ? ($_) : ()) ,
   ((*$gref{HASH}) ? ("%$_") : ()) ,
   ((*$gref{ARRAY}) ? "\@$_" : ()) ,
   ( !/^[ab]$/ && (eval('use strict; $' . $_), !$@) ? "\$$_" : ())
  )
 } keys %{'main::' . __PACKAGE__ . '::'};
}
#============================================================================
1;

__END__


=head1 NAME

raven::network - raVen's network functions

=head1 SYNOPSIS

use raven::network;

=head1 DESCRIPTION

function list:

=over

=item $byte=send_message($ip:port,$pwd,$hdr,$txt,$attr);

send message window to donald dick server

=back

=head1 SEE ALSO

hellcome to http://raven.elk.ru

=head1 AUTHOR

Dmitry Suhodoev, http://raven.elk.ru

=head1 QOPYRIGHT

(q) 2k2-4 by raVen

=cut
