#============================================================================
# raVen's web package
# $Id: web.pm,v 1.15 2004/03/08 12:22:31 raven Exp $
# (c) 2k2-4 by raVen
# ���� ����� ����� ������� � koi8-r :-)
#============================================================================
package raven::web;
use strict;
use raven::text;
use Class::Date;
use vars qw(@EXPORT @ISA);
use LWP::UserAgent;
use HTTP::Headers;
require Exporter;
@ISA = qw(Exporter);
#============================================================================
# %form=fill_form_data();
#----------------------------------------------------------------------------
sub fill_form_data() {
 my %form;
 return(%form) unless exists($ENV{'CONTENT_LENGTH'});
 read(STDIN, my $buffer, $ENV{'CONTENT_LENGTH'} || 0);
 my @pairs = split(/&/, $buffer);
 my $record_size = 0;
 foreach my $pair(@pairs) {
  my($name, $value) = split(/=/, $pair);
  $value =~ tr/+/ /;
  $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
  $record_size += length($value);
  $form{$name} = $value;
 }
 return(%form);
}
#============================================================================
# %uri=fill_form_data($uri);
#----------------------------------------------------------------------------
sub fill_uri_data($) {
 $_ = shift();
 s/^.*?\?//;
 my %result = ();
 return() if ($_ eq '');
 foreach(split(/\&/)) {
  my($key, $value) = split(/\=/);
  $value = '' unless (defined($value));
  $result{$key} = $value;
 }
 return(%result);
}
#============================================================================
# $text = get_period_select_form($begin_year);
#--( get_period_select_form )------------------------------------------------
sub get_period_select_form($) {
 my $beginyear = shift();
 my($sec, $min, $hour, $mday, $mon, $cyear, $wday, $yday, $isdst) = localtime(time);
 $cyear = $cyear % 100 + 2000; $mon++;

 my $indent = '  ';

 my $yearselect = '';
 while ($beginyear++ <= $cyear) {
  my $year = $beginyear - 1;
  if ($year != $cyear) {
   $yearselect .= qq~\n$indent<option value="$year">$year</option>~;
  } else {
   $yearselect .= qq~\n$indent<option selected value="$year">$year</option>~;
  }
 }

 my $mon1 = $mon;
 $mon-- if ($mday == 1);
 my $mon_select = '';
 my $mon_select1 = '';
 for (my $i = 0; $i < 12; $i++) {
  my $m = $i + 1;
  my $selected = '';
  $selected = ' selected' if ($m == $mon);
  $mon_select .= qq~\n$indent<option$selected value="$m">$month_names[$i]</option>~;
  $selected = '';
  $selected = ' selected' if ($m == $mon1);
  $mon_select1 .= qq~\n$indent<option$selected value="$m">$month_names[$i]</option>~;
 }

 my $day_select = '';
 my $day_select1 = '';
 my $test_date = Class::Date->new([$cyear, $mon, $mday, 9, 0, 0]);
 my $test_date1 = Class::Date->new([$cyear, $mon1, $mday, 9, 0, 0]);
 for (my $i = 1; $i <= 31; $i++) {
  my $selected = '';

  if ($test_date->days_in_month >= $i) {
   $selected = ' selected' if ($i + 1 == 1);
   $day_select .= qq~\n$indent<option$selected value="$i">$i</option>~;
  }

  $selected = '';
  if ($test_date1->days_in_month >= $i) {
   $selected = ' selected' if ($i == $mday);
   $day_select1 .= qq~\n$indent<option$selected value="$i">$i</option>~;
  }
 }

 return(qq~
 <script language="JavaScript" src='/js/populate.js' type="text/javascript"></script>
 <select name="startyear" onChange="populate(this.form.startyear,this.form.startmon,this.form.startday);">$yearselect
 </select>

 <select name="startmon" onChange="populate(this.form.startyear,this.form.startmon,this.form.startday);">$mon_select
 </select>

 <select name="startday">$day_select
 </select>

 ��

 <select name="endyear" onChange="populate(this.form.endyear,this.form.endmon,this.form.endday);">$yearselect
 </select>

 <select name="endmon" onChange="populate(this.form.endyear,this.form.endmon,this.form.endday);">$mon_select1
 </select>

 <select name="endday">$day_select1
 </select>~);
}
#============================================================================
# $rc = send_mail_message($kludges, $text)
#--( send_mail_message )-----------------------------------------------------
sub send_mail_message($$) {
 my $mailprog = '/usr/sbin/sendmail -t';
 my($kludges, $text) = (shift(), shift());
 open(MAIL,"|$mailprog") || return("can't open $mailprog: $!\n");
 print(MAIL "$kludges\n$text");
 close(MAIL);
 return(1);
}
#============================================================================
# $size = get_http_file_size($uri)
#--( get_http_file_size )----------------------------------------------------
sub get_http_file_size($) {
 my $h = HTTP::Headers->new(
  'Accept_Language'	=> 'ru',
  'Connection'		=> 'Close',
  'User-Agent'		=> 'Mozilla/4.0 (compatible; MSIE 5.0; Windows 98; DigExt)'
 );
 my $ua = LWP::UserAgent->new(env_proxy => 1);
 my $req = HTTP::Request->new('GET', shift(), $h);
 my $response = $ua->request($req, \&die);
 if ($response->is_success) {
  return($response->header('Content-Length'));
 } else {
  return(-1);
 }
}
#============================================================================
# �������������� ������� �����, ��� ����� ����
# (�) Andrey Sapozhnikov, sapa@icb.chel.su
{
 no strict "refs";
 @EXPORT = map {
  local $SIG{__WARN__} = sub { die @_ };
  my $gref = ${'main::' . __PACKAGE__ . '::'}{$_};
  /^[^a-z]|^isa$/ ? () : (
   ((*$gref{CODE}) ? ($_) : ()) ,
   ((*$gref{HASH}) ? ("%$_") : ()) ,
   ((*$gref{ARRAY}) ? "\@$_" : ()) ,
   ( !/^[ab]$/ && (eval('use strict; $' . $_), !$@) ? "\$$_" : ())
  )
 } keys %{'main::' . __PACKAGE__ . '::'};
}
#============================================================================
1;

__END__

=head1 NAME

raven::web - raVen's web functions

=head1 SYNOPSIS

use raven::web;

=head1 DESCRIPTION

function list:

=over

=item $text = clean_str($text);

clean html text from spare comments, cr/lf, spaces, tabs

=item %form = fill_form_data();

filling form by data from STDIN

=item $text = get_period_select_form();

get subform for selecting period

=back

=head1 SEE ALSO

hellcome to http://raven.elk.ru

=head1 AUTHOR

Dmitry Suhodoev, http://raven.elk.ru

=head1 QOPYRIGHT

(q) 2k2-4 by raVen

=cut
