#!/bin/sh

case "$1" in
	start)
		if [ -x /usr/home/kirill/GameClass/gclub ]; then
			/usr/home/kirill/GameClass/gclub 10.0.0.177 3773 2>/dev/null &
			echo -n ' gclub'
		fi
		;;
	stop)
		spid=`ps axww | grep gclub | grep -v grep | /usr/bin/awk '{print $1}'`
		/bin/kill ${spid}
		/usr/bin/killall gclub
		echo -n ' gclub'
		;;
	*)
		echo ""
		echo "Usage: `basename $0` { start | stop }"
		echo ""
		exit 0
		;;
esac
