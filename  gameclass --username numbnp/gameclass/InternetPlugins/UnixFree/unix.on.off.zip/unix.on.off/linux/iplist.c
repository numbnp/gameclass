// *****************************************************
// *              (C) NodaSoft 2000-2005               *
// *****************************************************

#include "iplist.h"

extern ipliststruct iplist[MAX_IPLIST];
extern int iplistmax;

// already exists checking
int IpListIn(char *ip)
{
  int i;
  for(i=0;i<iplistmax;i++)
    if(strstr(iplist[i].ip,ip))
	  return(1);

  return(0);
}

// add new ip to iplist
void IpListAdd(char *ip)
{
  int i;
  if (IpListIn(ip)) return;

  for(i=0;i<MAX_IPLIST;i++)
    if(iplist[i].ip[0]==0)
	{
	  strcpy(iplist[i].ip,ip);
	  if ((i+1)>iplistmax) iplistmax = i+1;
	  return;
	}
}

// remove ip from iplist
void IpListRemove(char *ip)
{
  int i;
  for(i=0;i<iplistmax;i++)
    if(strstr(iplist[i].ip,ip))
	{
	  iplist[i].ip[0] = 0;
	  return;
	}
}

// initialize iplist
void IpListInitialize(void)
{
  int i;
	
  iplistmax = 0;
	
  for(i=0;i<MAX_IPLIST;i++)
  {
    iplist[i].ip[0]=0;
    iplist[i].blocked=0;
    iplist[i].traf_speed=0;
    iplist[i].traf_limit=0;
    iplist[i].traf_in=0;
    iplist[i].traf_out=0;
  }
}

