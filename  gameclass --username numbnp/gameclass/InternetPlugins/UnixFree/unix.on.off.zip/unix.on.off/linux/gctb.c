// *****************************************************
// *              (C) NodaSoft 2000-2005               *
// *****************************************************
// *   Traffic Billing Module v 1.0 for GameClass      *
// *   HomePage http://www.nodasoft.com/products/gc    *
// *   Create by NodaSoft                              *
// *   Edition by Tahion, email: tahion at gmail.com   *
// *                                                   *
// *****************************************************

#include <netinet/in.h>                     
#include <sys/socket.h>
#include <stdio.h>
#include "iplist.h"
// Added by Tahion
#include <signal.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
#include <unistd.h>

ipliststruct iplist[MAX_IPLIST]; 	// iplist array
int	iplistmax;			// quantity ip in iplist (count elements in iplist)

char buffer[IN_BUFFER_LEN];		// buffer for udp-packet
char command[COMMAND_BUFFER_LEN];	// string with command for unix
char ip[16];				// ip address
char tarif_name[300];			// tarif_name
struct sockaddr_in local, from;


    FILE *in;
	char s[20];
	long x,y;
	int i;


// entry point
int main(void)
{
  // ------ socket's variables --------
  int fromlen;
  int listen_socket, msgsock;
  int k=0;
  int fd;
  struct  rlimit  flim;
  
  /*daemon initialisation part */
  if( getppid() != 1 ){
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    if( fork()!=0 ){
	exit(0);
    }
    setsid();
  }
  getrlimit(RLIMIT_NOFILE, &flim);
  for (fd = 0; fd < flim.rlim_max; fd++)close(fd);
  chdir("/");

  openlog("TbmGCd", LOG_PID | LOG_CONS, LOG_DAEMON);
  syslog(LOG_INFO, "daemon started");
  closelog();

  /*end of daemon initialisation part */
  // DELETING ALL RULES FROM tables
      strcpy(command,MODULE_PATH);
      strcat(command,"/reset_reject");
      system(command);

  printf("\n(C) NodaSoft 2000-2005\n");
  printf("(C) Edition by tahion, tahion at gmail.com\n");
  printf("Traffic Billing Module for GameClass is started ...\n");

  IpListInitialize();

  // initializing UDP socket
  local.sin_family = AF_INET;
  local.sin_addr.s_addr = htonl(INADDR_ANY);
  local.sin_port = htons(UDP_PORT);

  // can be socket open?
  listen_socket = socket(AF_INET, SOCK_DGRAM,0);
  if (listen_socket == -1) 
  {
    printf("Error: socket already opened!\n");
    openlog("TbmGCd", LOG_PID | LOG_CONS, LOG_DAEMON);
    syslog(LOG_INFO, "Error: socket already opened!");
    closelog();
    exit(1);
  }  
  if (bind(listen_socket,(struct sockaddr*)&local,sizeof(local) ) == -1) 
  {
    printf("Error: Listen socket!\n");
    openlog("TbmGCd", LOG_PID | LOG_CONS, LOG_DAEMON);
    syslog(LOG_INFO, "Error: Listen socket!");
    closelog();
    exit(1);
  }
  
  // socket open successfully  
  // go working

  while(1) 
  {
    fromlen = sizeof(from);
    msgsock = listen_socket;
    memset(buffer,0,IN_BUFFER_LEN);
	
	// waiting query (UDP-Packet) from GameClass Server
    recvfrom(msgsock,buffer,sizeof(buffer),0,(struct sockaddr *)&from,&fromlen);

	// command from server	
	/*********************************************/
    if (strstr(buffer,"inet_block"))
    {
      strcpy(command,MODULE_PATH);
      strcat(command,"/template_block ");
      strcat(command,strstr(buffer,"=")+1);
      strcpy(ip,strstr(buffer,"=")+1);
      if (IpListIn(ip)) 
	  {
        // here is added new Firewall rule (blocking)
	    system(command);				
	    IpListRemove(ip);
	  }
	}
    /*********************************************/
    if (strstr(buffer,"inet_unblock"))
    {
      strcpy(command,MODULE_PATH);
      strcat(command,"/template_unblock ");
	  
	  strcpy(tarif_name, "");
	  if (strstr(buffer,"/"))
	  {
		strcpy(tarif_name, strstr(buffer,"/")+1);
		*strstr(buffer,"/")=0;
		strcat(command,strstr(buffer,"=")+1);
		//strcat(command,strstr(tarif_name,"=")+1);
	  }
	  else
	  {
	  strcat(command,strstr(buffer,"=")+1);
	  };
      strcpy(ip,strstr(buffer,"=")+1);
	  
	  // ToDo Exctract second parameter - tarif name
      if (!IpListIn(ip)) 
	  {
        // here is romeved Firewall rule (unblocking)
	    printf("%s \n",command);
	    system(command);
	    IpListAdd(ip);
	  }

    }
    /*********************************************/
    if (strstr(buffer,"inet_set_speed_for_ip"))
    {
		// currently not supported
    }
  }
  close(listen_socket);
  return -1;
}